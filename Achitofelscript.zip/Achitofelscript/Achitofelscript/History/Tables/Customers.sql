﻿CREATE TABLE [History].[Customers] (
    [CustomerID]  INT           NOT NULL,
    [CompanyName] NVARCHAR (50) NOT NULL,
    [CompanySize] INT           NOT NULL,
    [Industry]    NVARCHAR (50) NULL,
    [Nationality] INT           NOT NULL,
    [TeamID]      INT           NOT NULL,
    [BlackList]   INT           NOT NULL,
    [ValidFrom]   DATETIME2 (7) NOT NULL,
    [ValidTo]     DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Customers]
    ON [History].[Customers]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

