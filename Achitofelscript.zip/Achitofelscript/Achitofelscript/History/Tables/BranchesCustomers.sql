﻿CREATE TABLE [History].[BranchesCustomers] (
    [CustomerID]        INT            NOT NULL,
    [CustomerBranchID]  INT            NOT NULL,
    [Street]            NVARCHAR (50)  NULL,
    [House#]            NVARCHAR (50)  NULL,
    [Unit_Flat#]        NVARCHAR (10)  NULL,
    [City]              NVARCHAR (50)  NULL,
    [Region]            NVARCHAR (50)  NULL,
    [PostCode]          NVARCHAR (50)  NULL,
    [Country]           NVARCHAR (50)  NULL,
    [DistanceAchitofel] NVARCHAR (200) NOT NULL,
    [NotesDelivery]     NVARCHAR (200) NULL,
    [HomePhone]         NVARCHAR (25)  NULL,
    [Fax]               NVARCHAR (25)  NULL,
    [ValidFrom]         DATETIME2 (7)  NOT NULL,
    [ValidTo]           DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_BranchesCustomers]
    ON [History].[BranchesCustomers]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

