﻿CREATE TABLE [History].[Managers_Customers] (
    [CustomerID]        INT            NOT NULL,
    [CustomerManagerID] INT            NOT NULL,
    [ManagerType]       INT            NOT NULL,
    [LastName]          NVARCHAR (50)  NOT NULL,
    [FirstName]         NVARCHAR (50)  NOT NULL,
    [TitleOfCourtesy]   INT            NOT NULL,
    [Gender]            INT            NOT NULL,
    [BirthDate]         DATETIME       NOT NULL,
    [CakeFlavor]        NVARCHAR (100) NOT NULL,
    [Notes]             NVARCHAR (200) NULL,
    [Street]            NVARCHAR (50)  NOT NULL,
    [House#]            NVARCHAR (50)  NOT NULL,
    [Unit_Flat#]        NVARCHAR (10)  NULL,
    [City]              NVARCHAR (50)  NOT NULL,
    [Region]            NVARCHAR (50)  NULL,
    [Postcode]          NVARCHAR (50)  NULL,
    [Country]           NVARCHAR (50)  NOT NULL,
    [NotesDelivery]     NVARCHAR (200) NULL,
    [HomePhone]         NVARCHAR (50)  NULL,
    [ValidFrom]         DATETIME2 (7)  NOT NULL,
    [ValidTo]           DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Managers_Customers]
    ON [History].[Managers_Customers]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

