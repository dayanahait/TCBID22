﻿CREATE TABLE [History].[Metrics] (
    [Code]          INT            NOT NULL,
    [ParameterType] INT            NOT NULL,
    [Details]       NVARCHAR (200) NOT NULL,
    [ValuePoint]    FLOAT (53)     NOT NULL,
    [StartDate]     DATETIME       NOT NULL,
    [EndDate]       DATETIME       NOT NULL,
    [ValidFrom]     DATETIME2 (7)  NOT NULL,
    [ValidTo]       DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Metrics]
    ON [History].[Metrics]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

