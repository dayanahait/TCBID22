﻿CREATE TABLE [History].[Invoices] (
    [InvoiceNumber] INT            NOT NULL,
    [CustomerID]    INT            NOT NULL,
    [DateIssued]    DATETIME       NOT NULL,
    [BlackListFee]  FLOAT (53)     NULL,
    [DueDate]       DATETIME       NOT NULL,
    [DatePaid]      DATETIME       NULL,
    [TotalFees]     MONEY          NOT NULL,
    [Discount]      FLOAT (53)     NULL,
    [AmountPayable] MONEY          NOT NULL,
    [Notes]         NVARCHAR (200) NULL,
    [ValidFrom]     DATETIME2 (7)  NOT NULL,
    [ValidTo]       DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Invoices]
    ON [History].[Invoices]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

