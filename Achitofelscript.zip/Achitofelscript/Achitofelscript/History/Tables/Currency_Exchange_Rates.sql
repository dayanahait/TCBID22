﻿CREATE TABLE [History].[Currency_Exchange_Rates] (
    [CurrencyType]  INT           NOT NULL,
    [ExchangeValue] MONEY         NOT NULL,
    [ValidFrom]     DATETIME2 (7) NOT NULL,
    [ValidTo]       DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Currency_Exchange_Rates]
    ON [History].[Currency_Exchange_Rates]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

