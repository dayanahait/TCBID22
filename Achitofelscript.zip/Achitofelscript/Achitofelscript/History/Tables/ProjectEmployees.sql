﻿CREATE TABLE [History].[ProjectEmployees] (
    [EmployeeID]        INT           NOT NULL,
    [ProjectID]         INT           NOT NULL,
    [ProjectRateHourly] INT           NOT NULL,
    [ValidFrom]         DATETIME2 (7) NOT NULL,
    [ValidTo]           DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_ProjectEmployees]
    ON [History].[ProjectEmployees]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

