﻿CREATE TABLE [History].[HoursReportEmployees] (
    [ProjectID]        INT           NOT NULL,
    [EmployeeID]       INT           NOT NULL,
    [ReportDate]       DATETIME      NOT NULL,
    [StartHour]        DATETIME      NOT NULL,
    [EndHour]          DATETIME      NOT NULL,
    [CustomerBranchID] INT           NOT NULL,
    [ValidFrom]        DATETIME2 (7) NOT NULL,
    [ValidTo]          DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_HoursReportEmployees]
    ON [History].[HoursReportEmployees]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

