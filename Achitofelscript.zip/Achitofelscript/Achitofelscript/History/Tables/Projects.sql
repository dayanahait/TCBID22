﻿CREATE TABLE [History].[Projects] (
    [ProjectID]         INT            NOT NULL,
    [CustomerManagerID] INT            NOT NULL,
    [CustomerID]        INT            NOT NULL,
    [ProjectName]       NVARCHAR (50)  NOT NULL,
    [StartDate]         DATETIME       NOT NULL,
    [EndDateEstimate]   DATETIME       NOT NULL,
    [EndDateActual]     DATETIME       NOT NULL,
    [Description_]      NVARCHAR (200) NOT NULL,
    [BlackList]         INT            NOT NULL,
    [NotesBL]           NVARCHAR (200) NOT NULL,
    [ValidFrom]         DATETIME2 (7)  NOT NULL,
    [ValidTo]           DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Projects]
    ON [History].[Projects]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

