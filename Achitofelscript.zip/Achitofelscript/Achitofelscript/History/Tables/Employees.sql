﻿CREATE TABLE [History].[Employees] (
    [EmployeeID]         INT            NOT NULL,
    [ID]                 CHAR (9)       NOT NULL,
    [Title]              INT            NOT NULL,
    [LastName]           NVARCHAR (50)  NOT NULL,
    [FirstName]          NVARCHAR (50)  NOT NULL,
    [TitleOfCourtesy]    INT            NOT NULL,
    [Gender]             INT            NOT NULL,
    [Status_]            INT            NOT NULL,
    [BirthDate]          DATETIME       NOT NULL,
    [HireDate]           DATETIME       NOT NULL,
    [EndDate]            DATETIME       NULL,
    [SDailyWHours]       FLOAT (53)     NOT NULL,
    [SalaryFirstBasic]   MONEY          NOT NULL,
    [SalaryCurrentBasic] MONEY          NOT NULL,
    [MobilePrivate]      NVARCHAR (25)  NULL,
    [MobileBusiness]     NVARCHAR (25)  NOT NULL,
    [EmailPrivate]       NVARCHAR (50)  NULL,
    [EmailBusiness]      NVARCHAR (50)  NOT NULL,
    [Extension]          NVARCHAR (6)   NULL,
    [ReportsTo]          INT            NULL,
    [Notes]              NVARCHAR (200) NULL,
    [ValidFrom]          DATETIME2 (7)  NOT NULL,
    [ValidTo]            DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Employees]
    ON [History].[Employees]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

