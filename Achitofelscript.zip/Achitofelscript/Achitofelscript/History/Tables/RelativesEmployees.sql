﻿CREATE TABLE [History].[RelativesEmployees] (
    [EmployeeID]      INT           NOT NULL,
    [ID]              CHAR (9)      NOT NULL,
    [Relationship]    INT           NOT NULL,
    [LastName]        NVARCHAR (35) NOT NULL,
    [FirstName]       NVARCHAR (35) NOT NULL,
    [TitleOfCourtesy] INT           NOT NULL,
    [BirthDate]       DATETIME      NOT NULL,
    [Gender]          INT           NOT NULL,
    [ValidFrom]       DATETIME2 (7) NOT NULL,
    [ValidTo]         DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_RelativesEmployees]
    ON [History].[RelativesEmployees]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

