﻿CREATE TABLE [History].[ManagerHearing] (
    [EmployeeID]  INT            NOT NULL,
    [HearingDate] DATETIME       NOT NULL,
    [Details]     NVARCHAR (200) NOT NULL,
    [Decision]    INT            NOT NULL,
    [ReportToHR]  BINARY (50)    NULL,
    [ValidFrom]   DATETIME2 (7)  NOT NULL,
    [ValidTo]     DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_ManagerHearing]
    ON [History].[ManagerHearing]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

