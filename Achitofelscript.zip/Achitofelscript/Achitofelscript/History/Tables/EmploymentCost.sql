﻿CREATE TABLE [History].[EmploymentCost] (
    [EmployeeID]         INT           NOT NULL,
    [CostDate]           DATETIME      NOT NULL,
    [SalaryCurrentBasic] MONEY         NOT NULL,
    [Benefits]           INT           NOT NULL,
    [OverTime]           INT           NULL,
    [ManagementBonus]    INT           NULL,
    [Travel]             INT           NULL,
    [VacationDays]       INT           NOT NULL,
    [Tax]                INT           NULL,
    [ValidFrom]          DATETIME2 (7) NOT NULL,
    [ValidTo]            DATETIME2 (7) NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_EmploymentCost]
    ON [History].[EmploymentCost]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

