﻿CREATE TABLE [History].[Benefits_Bonuses] (
    [SocialCode]        INT            NOT NULL,
    [BenefitName]       NVARCHAR (200) NOT NULL,
    [PercentageBenefit] FLOAT (53)     NOT NULL,
    [PercentageSalary]  FLOAT (53)     NOT NULL,
    [SalaryCode]        INT            NOT NULL,
    [ValidFrom]         DATETIME2 (7)  NOT NULL,
    [ValidTo]           DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_Benefits_Bonuses]
    ON [History].[Benefits_Bonuses]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

