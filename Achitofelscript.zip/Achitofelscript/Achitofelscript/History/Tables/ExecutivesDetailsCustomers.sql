﻿CREATE TABLE [History].[ExecutivesDetailsCustomers] (
    [CustomerManagerID] INT            NOT NULL,
    [Relationship]      NVARCHAR (10)  NOT NULL,
    [FirstName]         NVARCHAR (50)  NOT NULL,
    [LastName]          NVARCHAR (50)  NOT NULL,
    [Birthdate]         DATETIME       NOT NULL,
    [Street]            NVARCHAR (50)  NOT NULL,
    [House#]            NVARCHAR (50)  NOT NULL,
    [Unit_Flat#]        NVARCHAR (10)  NULL,
    [City]              NVARCHAR (50)  NOT NULL,
    [Region]            NVARCHAR (50)  NULL,
    [Postcode]          NVARCHAR (50)  NULL,
    [Country]           NVARCHAR (50)  NOT NULL,
    [NotesDelivery]     NVARCHAR (200) NULL,
    [CakeFlavor]        NVARCHAR (100) NOT NULL,
    [HomePhone]         NVARCHAR (25)  NOT NULL,
    [ValidFrom]         DATETIME2 (7)  NOT NULL,
    [ValidTo]           DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_ExecutivesDetailsCustomers]
    ON [History].[ExecutivesDetailsCustomers]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

