﻿CREATE TABLE [History].[HRHearing] (
    [EmployeeID]               INT            NOT NULL,
    [HearingDate]              DATETIME       NOT NULL,
    [Details]                  NVARCHAR (100) NOT NULL,
    [Decision]                 INT            NOT NULL,
    [Warning#]                 INT            NULL,
    [Notes]                    NVARCHAR (100) NULL,
    [DateLetterSocialSecurity] DATETIME       NULL,
    [ValidFrom]                DATETIME2 (7)  NOT NULL,
    [ValidTo]                  DATETIME2 (7)  NOT NULL
);


GO
CREATE CLUSTERED INDEX [ix_HRHearing]
    ON [History].[HRHearing]([ValidTo] ASC, [ValidFrom] ASC) WITH (DATA_COMPRESSION = PAGE);

