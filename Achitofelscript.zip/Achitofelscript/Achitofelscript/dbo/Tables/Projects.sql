﻿CREATE TABLE [dbo].[Projects] (
    [ProjectID]         INT                                                IDENTITY (1, 1) NOT NULL,
    [CustomerManagerID] INT                                                NOT NULL,
    [CustomerID]        INT                                                NOT NULL,
    [ProjectName]       NVARCHAR (50)                                      NOT NULL,
    [StartDate]         DATETIME                                           NOT NULL,
    [EndDateEstimate]   DATETIME                                           NOT NULL,
    [EndDateActual]     DATETIME                                           NOT NULL,
    [Description_]      NVARCHAR (200)                                     NOT NULL,
    [BlackList]         INT                                                NOT NULL,
    [NotesBL]           NVARCHAR (200)                                     NOT NULL,
    [ValidFrom]         DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys9] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]           DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys10] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Projects] PRIMARY KEY CLUSTERED ([ProjectID] ASC),
    CONSTRAINT [BlackList] CHECK ([dbo].[fn_no_billed_customers]([customerid])=(1)),
    CONSTRAINT [ProjectEndDateActual] CHECK ([EndDateActual]>[StartDate]),
    CONSTRAINT [ProjectEndDateEstimate] CHECK ([EndDateEstimate]>[StartDate]),
    FOREIGN KEY ([CustomerID]) REFERENCES [dbo].[Customers] ([CustomerID]),
    CONSTRAINT [FK__Projects__Custom__4CA06362] FOREIGN KEY ([CustomerManagerID]) REFERENCES [dbo].[Managers_Customers] ([CustomerManagerID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Projects], DATA_CONSISTENCY_CHECK=ON));

