﻿CREATE TABLE [dbo].[HoursReportEmployees] (
    [ProjectID]        INT                                                NOT NULL,
    [EmployeeID]       INT                                                NOT NULL,
    [ReportDate]       DATETIME                                           DEFAULT (getdate()) NOT NULL,
    [StartHour]        DATETIME                                           NOT NULL,
    [EndHour]          DATETIME                                           NOT NULL,
    [CustomerBranchID] INT                                                NOT NULL,
    [ValidFrom]        DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys13] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]          DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys14] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_HoursReportEmployees] PRIMARY KEY CLUSTERED ([EmployeeID] ASC),
    CONSTRAINT [BlackList_HoursReportEmployees] CHECK ([dbo].[fn_blackproject]([projectid])=(1)),
    CONSTRAINT [HoursReportEmployees_endhour] CHECK ([endhour]>[starthour]),
    FOREIGN KEY ([CustomerBranchID]) REFERENCES [dbo].[BranchesCustomers] ([CustomerBranchID]),
    FOREIGN KEY ([EmployeeID]) REFERENCES [dbo].[Employees] ([EmployeeID]),
    FOREIGN KEY ([ProjectID]) REFERENCES [dbo].[Projects] ([ProjectID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[HoursReportEmployees], DATA_CONSISTENCY_CHECK=ON));

