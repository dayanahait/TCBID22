﻿CREATE TABLE [dbo].[RelativesEmployees] (
    [EmployeeID]      INT                                                NOT NULL,
    [ID]              CHAR (9)                                           NOT NULL,
    [Relationship]    INT                                                NOT NULL,
    [LastName]        NVARCHAR (35)                                      NOT NULL,
    [FirstName]       NVARCHAR (35)                                      NOT NULL,
    [TitleOfCourtesy] INT                                                NOT NULL,
    [BirthDate]       DATETIME                                           NOT NULL,
    [Gender]          INT                                                NOT NULL,
    [ValidFrom]       DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys1] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]         DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys2] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_RelativesEmployees] PRIMARY KEY CLUSTERED ([ID] ASC),
    FOREIGN KEY ([Gender]) REFERENCES [dbo].[GenderC] ([GenderID]),
    FOREIGN KEY ([Gender]) REFERENCES [dbo].[GenderC] ([GenderID]),
    FOREIGN KEY ([Relationship]) REFERENCES [dbo].[RelationshipC] ([RelationshipID]),
    CONSTRAINT [FK__Relatives__Emplo__48CFD27E] FOREIGN KEY ([EmployeeID]) REFERENCES [dbo].[Employees] ([EmployeeID]),
    CONSTRAINT [FK__Relatives__Title__71D1E811] FOREIGN KEY ([TitleOfCourtesy]) REFERENCES [dbo].[TitleOfCourtesyC] ([TitleOfCourtesy]),
    CONSTRAINT [FK__Relatives__Title__7A672E12] FOREIGN KEY ([TitleOfCourtesy]) REFERENCES [dbo].[TitleOfCourtesyC] ([TitleOfCourtesy]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[RelativesEmployees], DATA_CONSISTENCY_CHECK=ON));

