﻿CREATE TABLE [dbo].[Customers] (
    [CustomerID]  INT                                                IDENTITY (1, 1) NOT NULL,
    [CompanyName] NVARCHAR (50)                                      NOT NULL,
    [CompanySize] INT                                                NOT NULL,
    [Industry]    NVARCHAR (50)                                      NULL,
    [Nationality] INT                                                NOT NULL,
    [TeamID]      INT                                                NOT NULL,
    [BlackList]   INT                                                NOT NULL,
    [ValidFrom]   DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys5] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]     DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys6] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED ([CustomerID] ASC),
    FOREIGN KEY ([CompanySize]) REFERENCES [dbo].[CompanySizeC] ([CompanySizeID]),
    FOREIGN KEY ([Nationality]) REFERENCES [dbo].[NationalityC] ([NationalityID]),
    FOREIGN KEY ([TeamID]) REFERENCES [dbo].[Teams] ([TeamID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Customers], DATA_CONSISTENCY_CHECK=ON));

