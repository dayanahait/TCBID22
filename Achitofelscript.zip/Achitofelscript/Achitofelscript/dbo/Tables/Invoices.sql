﻿CREATE TABLE [dbo].[Invoices] (
    [InvoiceNumber] INT                                                IDENTITY (1, 1) NOT NULL,
    [CustomerID]    INT                                                NOT NULL,
    [DateIssued]    DATETIME                                           NOT NULL,
    [BlackListFee]  FLOAT (53)                                         DEFAULT ((0)) NULL,
    [DueDate]       DATETIME                                           NOT NULL,
    [DatePaid]      DATETIME                                           NULL,
    [TotalFees]     MONEY                                              NOT NULL,
    [Discount]      FLOAT (53)                                         DEFAULT ((0)) NULL,
    [AmountPayable] MONEY                                              NOT NULL,
    [Notes]         NVARCHAR (200)                                     NULL,
    [ValidFrom]     DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys22] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]       DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys23] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Invoices] PRIMARY KEY CLUSTERED ([InvoiceNumber] ASC),
    FOREIGN KEY ([CustomerID]) REFERENCES [dbo].[Customers] ([CustomerID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Invoices], DATA_CONSISTENCY_CHECK=ON));

