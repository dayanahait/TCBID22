﻿CREATE TABLE [dbo].[ProjectEmployees] (
    [EmployeeID]        INT                                                NOT NULL,
    [ProjectID]         INT                                                NOT NULL,
    [ProjectRateHourly] INT                                                NOT NULL,
    [ValidFrom]         DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys11] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]           DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys12] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_ProjectEmployees] PRIMARY KEY CLUSTERED ([EmployeeID] ASC, [ProjectID] ASC),
    CONSTRAINT [BlackList_ProjectEmployees] CHECK ([dbo].[fn_blackproject]([projectid])=(1)),
    FOREIGN KEY ([EmployeeID]) REFERENCES [dbo].[Employees] ([EmployeeID]),
    FOREIGN KEY ([ProjectID]) REFERENCES [dbo].[Projects] ([ProjectID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[ProjectEmployees], DATA_CONSISTENCY_CHECK=ON));

