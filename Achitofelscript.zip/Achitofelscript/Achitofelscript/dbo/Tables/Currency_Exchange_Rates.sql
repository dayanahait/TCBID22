﻿CREATE TABLE [dbo].[Currency_Exchange_Rates] (
    [CurrencyType]  INT                                                NOT NULL,
    [ExchangeValue] MONEY                                              NOT NULL,
    [ValidFrom]     DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_SysS21] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]       DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_SysE22] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Currency_Exchange_Rates] PRIMARY KEY CLUSTERED ([CurrencyType] ASC),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Currency_Exchange_Rates], DATA_CONSISTENCY_CHECK=ON));

