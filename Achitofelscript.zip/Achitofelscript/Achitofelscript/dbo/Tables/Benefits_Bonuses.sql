﻿CREATE TABLE [dbo].[Benefits_Bonuses] (
    [SocialCode]        INT                                                IDENTITY (1, 1) NOT NULL,
    [BenefitName]       NVARCHAR (200)                                     NOT NULL,
    [PercentageBenefit] FLOAT (53)                                         NOT NULL,
    [PercentageSalary]  FLOAT (53)                                         NOT NULL,
    [SalaryCode]        INT                                                NOT NULL,
    [ValidFrom]         DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys3] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]           DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys4] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Benefits_Bonuses] PRIMARY KEY CLUSTERED ([SocialCode] ASC),
    CONSTRAINT [PercentageSalary] CHECK ([PercentageSalary]<=(1)),
    FOREIGN KEY ([SalaryCode]) REFERENCES [dbo].[Benefits_BonusesC] ([SalaryCodeID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Benefits_Bonuses], DATA_CONSISTENCY_CHECK=ON));

