﻿CREATE TABLE [dbo].[Addresses_RelativesEmployees] (
    [ID]            INT            IDENTITY (1, 1) NOT NULL,
    [AddressType]   INT            NOT NULL,
    [Street]        NVARCHAR (50)  NOT NULL,
    [House#]        NVARCHAR (50)  NOT NULL,
    [Unit_Flat#]    NVARCHAR (10)  NULL,
    [City]          NVARCHAR (50)  NOT NULL,
    [Region]        NVARCHAR (50)  NULL,
    [Postcode]      NVARCHAR (50)  NULL,
    [Country]       NVARCHAR (50)  NOT NULL,
    [NotesDelivery] NVARCHAR (200) NULL,
    [HomePhone]     NVARCHAR (50)  NULL,
    CONSTRAINT [PK_Addresses_RelativesEmployees] PRIMARY KEY CLUSTERED ([ID] ASC),
    FOREIGN KEY ([AddressType]) REFERENCES [dbo].[AddressTypeC] ([AddressTypeID])
);

