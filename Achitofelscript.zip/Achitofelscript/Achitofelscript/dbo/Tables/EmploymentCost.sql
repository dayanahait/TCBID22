﻿CREATE TABLE [dbo].[EmploymentCost] (
    [EmployeeID]         INT                                                NOT NULL,
    [CostDate]           DATETIME                                           NOT NULL,
    [SalaryCurrentBasic] MONEY                                              NOT NULL,
    [Benefits]           INT                                                NOT NULL,
    [OverTime]           INT                                                NULL,
    [ManagementBonus]    INT                                                NULL,
    [Travel]             INT                                                NULL,
    [VacationDays]       INT                                                NOT NULL,
    [Tax]                INT                                                NULL,
    [ValidFrom]          DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_SysS29] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]            DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys30] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_EmploymentCost] PRIMARY KEY CLUSTERED ([EmployeeID] ASC),
    FOREIGN KEY ([EmployeeID]) REFERENCES [dbo].[Employees] ([EmployeeID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[EmploymentCost], DATA_CONSISTENCY_CHECK=ON));

