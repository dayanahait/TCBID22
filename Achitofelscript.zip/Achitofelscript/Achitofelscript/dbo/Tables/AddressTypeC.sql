﻿CREATE TABLE [dbo].[AddressTypeC] (
    [AddressTypeID] INT           IDENTITY (1, 1) NOT NULL,
    [Value]         NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([AddressTypeID] ASC)
);

