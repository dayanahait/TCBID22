﻿CREATE TABLE [dbo].[ManagerHearing] (
    [EmployeeID]  INT                                                NOT NULL,
    [HearingDate] DATETIME                                           NOT NULL,
    [Details]     NVARCHAR (200)                                     NOT NULL,
    [Decision]    INT                                                NOT NULL,
    [ReportToHR]  BINARY (50)                                        NULL,
    [ValidFrom]   DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_SysS24] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]     DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys25] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_ManagerHearing] PRIMARY KEY CLUSTERED ([EmployeeID] ASC),
    FOREIGN KEY ([Decision]) REFERENCES [dbo].[DecisionMC] ([DecisionMID]),
    FOREIGN KEY ([EmployeeID]) REFERENCES [dbo].[Employees] ([EmployeeID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[ManagerHearing], DATA_CONSISTENCY_CHECK=ON));

