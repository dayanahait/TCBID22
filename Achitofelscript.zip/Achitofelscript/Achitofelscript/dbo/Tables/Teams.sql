﻿CREATE TABLE [dbo].[Teams] (
    [TeamID]     INT                                                IDENTITY (1, 1) NOT NULL,
    [EmployeeID] INT                                                NOT NULL,
    [ValidFrom]  DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys7] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]    DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys8] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Teams] PRIMARY KEY CLUSTERED ([TeamID] ASC),
    FOREIGN KEY ([EmployeeID]) REFERENCES [dbo].[Employees] ([EmployeeID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Teams], DATA_CONSISTENCY_CHECK=ON));

