﻿CREATE TABLE [dbo].[RelationshipC] (
    [RelationshipID] INT           IDENTITY (1, 1) NOT NULL,
    [Value]          NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([RelationshipID] ASC)
);

