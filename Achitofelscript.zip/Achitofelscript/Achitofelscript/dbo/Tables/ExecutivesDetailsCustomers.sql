﻿CREATE TABLE [dbo].[ExecutivesDetailsCustomers] (
    [CustomerManagerID] INT                                                IDENTITY (1, 1) NOT NULL,
    [Relationship]      NVARCHAR (10)                                      NOT NULL,
    [FirstName]         NVARCHAR (50)                                      NOT NULL,
    [LastName]          NVARCHAR (50)                                      NOT NULL,
    [Birthdate]         DATETIME                                           NOT NULL,
    [Street]            NVARCHAR (50)                                      NOT NULL,
    [House#]            NVARCHAR (50)                                      NOT NULL,
    [Unit_Flat#]        NVARCHAR (10)                                      NULL,
    [City]              NVARCHAR (50)                                      NOT NULL,
    [Region]            NVARCHAR (50)                                      NULL,
    [Postcode]          NVARCHAR (50)                                      NULL,
    [Country]           NVARCHAR (50)                                      NOT NULL,
    [NotesDelivery]     NVARCHAR (200)                                     NULL,
    [CakeFlavor]        NVARCHAR (100)                                     NOT NULL,
    [HomePhone]         NVARCHAR (25)                                      NOT NULL,
    [ValidFrom]         DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_SysS19] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]           DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys20] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_ExecutivesDetailsCustomers] PRIMARY KEY CLUSTERED ([CustomerManagerID] ASC),
    CONSTRAINT [FK__Executive__Custo__5441852A] FOREIGN KEY ([CustomerManagerID]) REFERENCES [dbo].[Managers_Customers] ([CustomerManagerID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[ExecutivesDetailsCustomers], DATA_CONSISTENCY_CHECK=ON));

