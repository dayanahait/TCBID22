﻿CREATE TABLE [dbo].[BranchesCustomers] (
    [CustomerID]        INT                                                NOT NULL,
    [CustomerBranchID]  INT                                                IDENTITY (1, 1) NOT NULL,
    [Street]            NVARCHAR (50)                                      NULL,
    [House#]            NVARCHAR (50)                                      NULL,
    [Unit_Flat#]        NVARCHAR (10)                                      NULL,
    [City]              NVARCHAR (50)                                      NULL,
    [Region]            NVARCHAR (50)                                      NULL,
    [PostCode]          NVARCHAR (50)                                      NULL,
    [Country]           NVARCHAR (50)                                      NULL,
    [DistanceAchitofel] NVARCHAR (200)                                     NOT NULL,
    [NotesDelivery]     NVARCHAR (200)                                     NULL,
    [HomePhone]         NVARCHAR (25)                                      NULL,
    [Fax]               NVARCHAR (25)                                      NULL,
    [ValidFrom]         DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_Sys15] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]           DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys16] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_BranchesCustomers] PRIMARY KEY CLUSTERED ([CustomerBranchID] ASC),
    FOREIGN KEY ([CustomerID]) REFERENCES [dbo].[Customers] ([CustomerID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[BranchesCustomers], DATA_CONSISTENCY_CHECK=ON));

