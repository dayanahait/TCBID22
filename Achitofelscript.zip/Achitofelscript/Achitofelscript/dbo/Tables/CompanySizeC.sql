﻿CREATE TABLE [dbo].[CompanySizeC] (
    [CompanySizeID] INT           IDENTITY (1, 1) NOT NULL,
    [Value]         NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([CompanySizeID] ASC)
);

