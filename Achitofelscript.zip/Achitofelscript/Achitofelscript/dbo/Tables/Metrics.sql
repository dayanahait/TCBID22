﻿CREATE TABLE [dbo].[Metrics] (
    [Code]          INT                                                IDENTITY (1, 1) NOT NULL,
    [ParameterType] INT                                                NOT NULL,
    [Details]       NVARCHAR (200)                                     NOT NULL,
    [ValuePoint]    FLOAT (53)                                         NOT NULL,
    [StartDate]     DATETIME                                           NOT NULL,
    [EndDate]       DATETIME                                           NOT NULL,
    [ValidFrom]     DATETIME2 (7) GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT [DF_SysS28] DEFAULT (sysutcdatetime()) NOT NULL,
    [ValidTo]       DATETIME2 (7) GENERATED ALWAYS AS ROW END HIDDEN   CONSTRAINT [DF_Sys29] DEFAULT (CONVERT([datetime2],'9999-12-31 23:59:59.9999999')) NOT NULL,
    CONSTRAINT [PK_Metrics] PRIMARY KEY CLUSTERED ([Code] ASC),
    FOREIGN KEY ([ParameterType]) REFERENCES [dbo].[ParameterTypeC] ([ParameterTypeID]),
    PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE=[History].[Metrics], DATA_CONSISTENCY_CHECK=ON));

