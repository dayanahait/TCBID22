﻿
	create function dbo.fn_no_billed_customers( @customerid int )  
	returns bit  
	as 
	begin
	-- black list return  0   -- other  - retrun 1
		declare @b bit = 1 
		if exists		 ( select 1
				from Invoices 
				where CustomerID = @customerid 
				and getdate()>duedate and datepaid is null)
		set @b =0
		return @b
	end