﻿create function dbo.fn_blackproject( @projectid int )  
	returns bit  
	as 
	begin
	-- black list return  0   -- other  - retrun 1
		declare @b bit = 1 
		if exists		 ( select 1
				from projects
				where ProjectID = @ProjectID and blacklist =1)
				set @b =0
		return @b
	end