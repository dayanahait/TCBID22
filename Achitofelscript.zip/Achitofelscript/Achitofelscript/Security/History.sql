﻿CREATE SCHEMA [History]
    AUTHORIZATION [dbo];

